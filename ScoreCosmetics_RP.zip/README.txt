ScoreCosmetics - Resource Pack
ScoreStudio | mc.uzpvp.uz

Original resource pack by the team behind Hoplite.
Emissive textures, secret weapons and icons by vred_.

Modified by ScoreStudio for use with the HopliteCosmetics plugin:
- Removed unused namespaces (modelengine, space, ui) to reduce file size.
- Removed the unused overlay_1_21_4 folder (was never activated in pack.mcmeta).
- Rebranded pack icon and description.
