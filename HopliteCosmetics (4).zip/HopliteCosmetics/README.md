# HopliteCosmetics ("ScoreCosmetics")

ScoreStudio | mc.uzpvp.uz — Paper/Purpur 1.21.11

A GUI-based cosmetic hat plugin with 201 hats, paginated 45-per-page,
access controlled entirely through LuckPerms permissions, and hats
that "stick" to the player once equipped until removed via the menu.

## What's new in this version

1. **Wings removed entirely.** Both the Java code (WingManager,
   WingDisplayManager, WingsGUI, WingsCommand) and the RP files
   (stick.json, the wings model/texture folder) are gone. Only the hat
   system remains.

2. **Pagination bug fixed.** Next/Previous Page now actually works.
   The root cause: the old code called `Bukkit.createInventory(...)`
   again every time the page changed, creating a brand new `Inventory`
   object that the player's already-open menu had no connection to -
   so the screen never visually updated. The fix creates the
   `Inventory` exactly once per GUI session and only ever calls
   `inventory.setItem(...)` to rewrite its contents when changing pages.

3. **Per-hat LuckPerms permissions.** Every hat now has its own
   permission node, `hoplitecosmetics.hat.<id>` (all default `false`,
   declared in `plugin.yml`). There is no more internal "unlock list" -
   granting the permission node through LuckPerms is the only way to
   give a player access to a hat:
   ```
   /lp user <player> permission set hoplitecosmetics.hat.dragon_hat true
   /lp group vip permission set hoplitecosmetics.hat.king_crown true
   ```
   Use `/cosmeticsadmin listhats [filter]` in-game to look up the
   exact permission node for any hat without digging through config.yml.

4. **Hats can't be removed except via the menu.** Once equipped, a hat
   cannot be: clicked or shift-clicked out of the helmet slot, dragged
   out, dropped with Q, swapped to the off-hand, or lost on death (it's
   carried through respawn automatically). The only way to remove it
   is the "Remove Hat" button inside `/cosmetics`. See
   `HatLockListener.java` for the full implementation - it's a single,
   well-commented file if you want to audit exactly what's blocked and why.

   One honest limitation: this blocks all *normal* inventory
   interactions and vanilla events. It cannot stop another plugin that
   directly calls `PlayerInventory.clear()` or `setHelmet(null)` in its
   own code (e.g. a custom arena/kit plugin resetting gear) - that kind
   of direct API call bypasses Bukkit's event system entirely, so no
   listener-based plugin (including this one) can intercept it.

5. **RP cleaned up and rebranded.**
   - Removed unused namespaces: `modelengine`, `space`, `ui` (none of
     them were referenced by the hat system - they were Hoplite's own
     mob-model/font/shop-GUI assets, unrelated to this plugin).
   - Removed the dead `overlay_1_21_4` folder (was never activated -
     `pack.mcmeta` had no `overlays` entry pointing to it).
   - Pack icon replaced with the new ScoreStudio logo (`pack.png`).
   - Pack description changed to "ScoreCosmetics - Resource Pack".
   - Result: `ScoreCosmetics_RP.zip`, down from ~3.4MB to ~3.3MB.

## "Which item is this?" (F3+H) tooltip

You asked whether the `minecraft:coal` advanced-tooltip text (visible
only when a player enables F3+H, Minecraft's debug "advanced
tooltips" mode) can be hidden. It can't - that label is generated
entirely client-side by Minecraft's debug overlay and is not something
any server-side plugin can suppress. It's also off by default and
essentially never seen by normal players, so it shouldn't be a
practical concern.

## Build

```bash
cd HopliteCosmetics
mvn clean package
```

Output: `target/HopliteCosmetics-1.0.0.jar` → drop into `plugins/`.

> **Note:** This sandbox has no Maven/javac available, so the jar
> could not be compiled here. Every Paper/Adventure API call used
> (`ResourcePackInfo`, `PlayerResourcePackStatusEvent`,
> `InventoryClickEvent`/`InventoryAction`, `PlayerDeathEvent`,
> `PlayerSwapHandItemsEvent`, etc.) was individually verified against
> the official 1.21.11 Javadocs. If `mvn clean package` reports an
> error on your machine, send me the exact message and I'll fix it
> immediately.

## Resource pack setup

`ScoreCosmetics_RP.zip` is delivered alongside the plugin.

1. Upload it to your hosting (GitHub Releases recommended for a
   reliable, rate-limit-free direct download link).
2. Update `config.yml`:
   - `resource-pack.url` → wherever you uploaded it.
   - `resource-pack.sha1` → already filled in as
     `8f13072f1074fbaf95cd49dfc08dce3adc55683f`, which matches this
     exact file. If you re-zip it yourself, recompute with `sha1sum`.
3. Restart the server.

> Your previous resource pack link (the `funmoney.alwaysdata.net`
> one) had a request rate limit of 30/minute - fine for testing, but
> risky if many players join at once. GitHub Releases has no such limit.

## Commands

- `/cosmetics` — opens the paginated hat selection GUI (45 hats/page).
- `/cosmeticsadmin reload` — reloads config.yml (hat list, messages, etc).
- `/cosmeticsadmin listhats [filter]` — prints each hat's id and
  permission node, optionally filtered by text in the id or display name.

New players get **no hats unlocked by default** - every hat must be
granted explicitly via its permission node through LuckPerms.

## Adding more hats

Add an entry under `hats:` in `config.yml` with the `custom-model-data`
value from the RP's `assets/minecraft/items/coal.json`:

```yaml
hats:
  new_hat_id:
    display-name: "&fNew Hat"
    custom-model-data: 99
    icon-material: COAL
    lore: []
```

Then also add the matching permission to `plugin.yml` under
`permissions:` (so `/lp` tab-completion and `hasPermission` checks see
it cleanly):

```yaml
  hoplitecosmetics.hat.new_hat_id:
    description: Allows wearing the New Hat hat.
    default: false
```

Then `/cosmeticsadmin reload`.

## File structure

```
src/main/java/com/scorestudio/hoplitecosmetics/
├── HopliteCosmetics.java          - main plugin class
├── commands/
│   ├── CosmeticsCommand.java      - /cosmetics
│   └── CosmeticsAdminCommand.java - /cosmeticsadmin
├── gui/
│   └── CosmeticsGUI.java          - paginated hat menu (bug-fixed pagination)
├── listener/
│   ├── GUIListener.java           - handles menu clicks
│   ├── HatLockListener.java       - makes equipped hats "stick"
│   └── ResourcePackListener.java  - RP sending/enforcement + restore-on-join
├── manager/
│   ├── HatManager.java            - loads hats from config, page math
│   ├── PlayerDataManager.java     - YAML storage (just equipped-hat now)
│   └── CosmeticsManager.java      - equip/remove/death-restore logic
└── model/
    └── HatDefinition.java         - one hat's data + its permission node
```
