package com.scorestudio.hoplitecosmetics.gui;

import com.scorestudio.hoplitecosmetics.manager.HatManager;
import com.scorestudio.hoplitecosmetics.manager.PlayerDataManager;
import com.scorestudio.hoplitecosmetics.model.HatDefinition;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Paginated inventory GUI showing every configured cosmetic hat.
 *
 * Layout (54-slot / 6-row inventory):
 *   Slots 0-44  (rows 1-5): up to 45 hat icons for the current page.
 *   Slots 45-53 (row 6):    navigation bar - filler glass panes, with
 *                           a "Previous Page" button, a "Remove Hat"
 *                           button, and a "Next Page" button.
 *
 * IMPORTANT: the backing {@link Inventory} is created exactly ONCE in
 * the constructor and reused for the lifetime of this GUI instance.
 * Page changes only call inventory.setItem(...) to rewrite its
 * contents - they never call Bukkit.createInventory(...) again.
 * Creating a brand new Inventory object on every page change was the
 * original pagination bug: the player's client stays attached to
 * whichever Inventory object was open when they called openInventory(),
 * so replacing `this.inventory` with a new object after that point has
 * no visible effect - the player keeps looking at the old one forever.
 */
public class CosmeticsGUI implements InventoryHolder {

    public static final int HATS_PER_PAGE = 45;
    public static final int INVENTORY_SIZE = 54;
    public static final int PREV_PAGE_SLOT = 45;
    public static final int REMOVE_HAT_SLOT = 49;
    public static final int NEXT_PAGE_SLOT = 53;

    private final Plugin plugin;
    private final HatManager hatManager;
    private final PlayerDataManager playerDataManager;
    private final Player viewer;

    private final Inventory inventory;
    private int page;

    // Maps GUI slot -> hat id for the CURRENT page only, rebuilt on every render().
    private final Map<Integer, String> slotToHatId = new HashMap<>();

    public CosmeticsGUI(Plugin plugin, HatManager hatManager, PlayerDataManager playerDataManager, Player viewer) {
        this(plugin, hatManager, playerDataManager, viewer, 0);
    }

    public CosmeticsGUI(Plugin plugin, HatManager hatManager, PlayerDataManager playerDataManager, Player viewer, int page) {
        this.plugin = plugin;
        this.hatManager = hatManager;
        this.playerDataManager = playerDataManager;
        this.viewer = viewer;
        this.page = Math.max(0, page);

        // Create the Inventory object exactly once. The title is static -
        // Bukkit's InventoryView.setTitle() is officially documented as
        // broken/unsupported for live updates, so the current page number
        // is shown via the "Page X/Y" indicator item in the nav bar instead.
        String titleRaw = plugin.getConfig().getString("gui.title", "&8&l✦ &6Cosmetics &8&l✦");
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(titleRaw);
        this.inventory = Bukkit.createInventory(this, INVENTORY_SIZE, title);

        render();
    }

    private int getTotalPages() {
        return hatManager.getTotalPages(HATS_PER_PAGE);
    }

    /**
     * Rewrites the contents of the existing inventory for the current
     * page. Never creates a new Inventory object - see class javadoc.
     */
    private void render() {
        int totalPages = getTotalPages();
        if (page >= totalPages) page = Math.max(0, totalPages - 1);

        slotToHatId.clear();

        // Fill the entire inventory with background filler first.
        String fillerMatName = plugin.getConfig().getString("gui.filler-material", "GRAY_STAINED_GLASS_PANE");
        Material fillerMat = Material.matchMaterial(fillerMatName);
        if (fillerMat == null) fillerMat = Material.GRAY_STAINED_GLASS_PANE;

        ItemStack filler = new ItemStack(fillerMat);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.displayName(Component.empty());
            filler.setItemMeta(fillerMeta);
        }
        for (int i = 0; i < INVENTORY_SIZE; i++) {
            inventory.setItem(i, filler);
        }

        // Place hat icons for the current page into slots 0-44.
        List<HatDefinition> ordered = hatManager.getOrderedHats();
        int startIndex = page * HATS_PER_PAGE;
        int endIndex = Math.min(startIndex + HATS_PER_PAGE, ordered.size());

        String equippedHatId = playerDataManager.getEquippedHat(viewer.getUniqueId());

        for (int i = startIndex; i < endIndex; i++) {
            HatDefinition hat = ordered.get(i);
            int slot = i - startIndex; // 0..44

            boolean unlocked = viewer.hasPermission(hat.getPermission());
            boolean equipped = hat.getId().equals(equippedHatId);

            ItemStack icon = hat.buildMenuIcon(equipped, unlocked);
            inventory.setItem(slot, icon);
            slotToHatId.put(slot, hat.getId());
        }

        buildNavigationBar(totalPages);
    }

    private void buildNavigationBar(int totalPages) {
        // Previous page button (only if not on the first page).
        if (page > 0) {
            ItemStack prevItem = new ItemStack(Material.ARROW);
            ItemMeta prevMeta = prevItem.getItemMeta();
            if (prevMeta != null) {
                prevMeta.displayName(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&e&l« Previous Page")
                        .decoration(TextDecoration.ITALIC, false));
                List<Component> lore = new ArrayList<>();
                lore.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7Go to page " + page)
                        .decoration(TextDecoration.ITALIC, false));
                prevMeta.lore(lore);
                prevItem.setItemMeta(prevMeta);
            }
            inventory.setItem(PREV_PAGE_SLOT, prevItem);
        } else {
            inventory.setItem(PREV_PAGE_SLOT, blankFiller());
        }

        // Remove hat button (always present, center of nav bar).
        String removeName = plugin.getConfig().getString("gui.remove-hat-name", "&c&lRemove Hat");
        List<String> removeLoreRaw = plugin.getConfig().getStringList("gui.remove-hat-lore");

        ItemStack removeItem = new ItemStack(Material.BARRIER);
        ItemMeta removeMeta = removeItem.getItemMeta();
        if (removeMeta != null) {
            removeMeta.displayName(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize(removeName)
                    .decoration(TextDecoration.ITALIC, false));

            List<Component> lore = new ArrayList<>();
            for (String line : removeLoreRaw) {
                lore.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize(line)
                        .decoration(TextDecoration.ITALIC, false));
            }
            removeMeta.lore(lore);
            removeItem.setItemMeta(removeMeta);
        }
        inventory.setItem(REMOVE_HAT_SLOT, removeItem);

        // Page indicator (informational only, center-left of nav bar, non-interactive).
        ItemStack pageIndicator = new ItemStack(Material.PAPER);
        ItemMeta pageMeta = pageIndicator.getItemMeta();
        if (pageMeta != null) {
            pageMeta.displayName(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&6&lPage " + (page + 1) + "/" + totalPages)
                    .decoration(TextDecoration.ITALIC, false));
            pageIndicator.setItemMeta(pageMeta);
        }
        inventory.setItem(47, pageIndicator);

        // Next page button (only if more pages exist).
        if (page < totalPages - 1) {
            ItemStack nextItem = new ItemStack(Material.ARROW);
            ItemMeta nextMeta = nextItem.getItemMeta();
            if (nextMeta != null) {
                nextMeta.displayName(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&e&lNext Page »")
                        .decoration(TextDecoration.ITALIC, false));
                List<Component> lore = new ArrayList<>();
                lore.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7Go to page " + (page + 2))
                        .decoration(TextDecoration.ITALIC, false));
                nextMeta.lore(lore);
                nextItem.setItemMeta(nextMeta);
            }
            inventory.setItem(NEXT_PAGE_SLOT, nextItem);
        } else {
            inventory.setItem(NEXT_PAGE_SLOT, blankFiller());
        }
    }

    private ItemStack blankFiller() {
        String fillerMatName = plugin.getConfig().getString("gui.filler-material", "GRAY_STAINED_GLASS_PANE");
        Material fillerMat = Material.matchMaterial(fillerMatName);
        if (fillerMat == null) fillerMat = Material.GRAY_STAINED_GLASS_PANE;
        ItemStack filler = new ItemStack(fillerMat);
        ItemMeta meta = filler.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.empty());
            filler.setItemMeta(meta);
        }
        return filler;
    }

    public void open() {
        viewer.openInventory(inventory);
    }

    /** Rebuilds the current page in place (e.g. after equipping/removing a hat). */
    public void refresh() {
        render();
    }

    /** Changes to a different page and rewrites the SAME inventory's contents. */
    public void setPage(int newPage) {
        int totalPages = getTotalPages();
        this.page = Math.max(0, Math.min(newPage, totalPages - 1));
        render();
    }

    public int getPage() {
        return page;
    }

    /**
     * Returns the hat id associated with a clicked slot on the CURRENT
     * page, or null if the slot does not correspond to a hat (filler,
     * navigation button, empty, etc).
     */
    public String getHatIdAt(int slot) {
        return slotToHatId.get(slot);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
