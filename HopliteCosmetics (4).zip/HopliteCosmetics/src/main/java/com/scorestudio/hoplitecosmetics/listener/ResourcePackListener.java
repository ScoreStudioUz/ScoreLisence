package com.scorestudio.hoplitecosmetics.listener;

import com.scorestudio.hoplitecosmetics.manager.CosmeticsManager;
import com.scorestudio.hoplitecosmetics.manager.PlayerDataManager;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.plugin.Plugin;

import java.net.URI;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;

/**
 * Sends the ScoreCosmetics resource pack to every player on join and,
 * when resource-pack.mandatory is true in config.yml, enforces
 * acceptance by kicking players who decline or fail to download it.
 *
 * This mirrors how servers like Hoplite/MCC gate cosmetics behind a
 * required RP: the player literally cannot see (or use) custom hats
 * without it, so we make accepting it a hard requirement up front
 * rather than silently degrading to invisible items.
 */
public class ResourcePackListener implements Listener {

    private final Plugin plugin;
    private final CosmeticsManager cosmeticsManager;
    private final PlayerDataManager playerDataManager;

    // Tracks players we are still waiting on a resource pack response from,
    // so we don't double-kick or double-restore.
    private final Set<UUID> pendingResponse = ConcurrentHashMap.newKeySet();

    // Tracks players who have successfully loaded the resource pack this
    // session. Used by /cosmetics to refuse opening the menu when
    // resource-pack.mandatory is false and the player skipped/declined the RP.
    private final Set<UUID> rpLoaded = ConcurrentHashMap.newKeySet();

    public ResourcePackListener(Plugin plugin, CosmeticsManager cosmeticsManager, PlayerDataManager playerDataManager) {
        this.plugin = plugin;
        this.cosmeticsManager = cosmeticsManager;
        this.playerDataManager = playerDataManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        playerDataManager.load(player.getUniqueId());
        sendResourcePack(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        pendingResponse.remove(player.getUniqueId());
        rpLoaded.remove(player.getUniqueId());
        playerDataManager.unload(player.getUniqueId());
    }

    private void sendResourcePack(Player player) {
        String urlStr = plugin.getConfig().getString("resource-pack.url", "");
        if (urlStr == null || urlStr.isBlank() || urlStr.contains("example.com")) {
            plugin.getLogger().warning("resource-pack.url is not configured in config.yml! " +
                    "Resource pack was not sent. Please set resource-pack.url to a valid direct download link.");
            return;
        }

        URI uri;
        try {
            uri = URI.create(urlStr);
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().severe("resource-pack.url is malformed: " + urlStr);
            return;
        }

        String sha1Hex = plugin.getConfig().getString("resource-pack.sha1", "");
        String promptRaw = plugin.getConfig().getString("resource-pack.prompt-message", "&6A resource pack is required.");
        boolean mandatory = plugin.getConfig().getBoolean("resource-pack.mandatory", true);

        ResourcePackInfo.Builder infoBuilder = ResourcePackInfo.resourcePackInfo()
                .id(UUID.nameUUIDFromBytes(urlStr.getBytes()))
                .uri(uri);

        if (sha1Hex != null && !sha1Hex.isBlank()) {
            try {
                infoBuilder.hash(sha1Hex.trim());
            } catch (Exception ex) {
                plugin.getLogger().warning("resource-pack.sha1 is malformed, ignoring it: " + sha1Hex);
            }
        }

        ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                .packs(infoBuilder.build())
                .required(mandatory)
                .prompt(LegacyComponentSerializer.legacyAmpersand().deserialize(promptRaw))
                .build();

        pendingResponse.add(player.getUniqueId());
        player.sendResourcePacks(request);
    }

    @EventHandler
    public void onResourcePackStatus(PlayerResourcePackStatusEvent event) {
        Player player = event.getPlayer();
        PlayerResourcePackStatusEvent.Status status = event.getStatus();
        boolean mandatory = plugin.getConfig().getBoolean("resource-pack.mandatory", true);

        switch (status) {
            case SUCCESSFULLY_LOADED -> {
                pendingResponse.remove(player.getUniqueId());
                rpLoaded.add(player.getUniqueId());
                // RP fully loaded - restore the hat the player had equipped
                // when they last logged off (see class javadoc on
                // CosmeticsManager for why this is enforced as "stuck"
                // until explicitly removed via the menu).
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        cosmeticsManager.restoreEquippedHat(player);
                    }
                });
            }
            case DECLINED -> {
                pendingResponse.remove(player.getUniqueId());
                if (mandatory) {
                    String kickMsg = plugin.getConfig().getString("resource-pack.decline-kick-message",
                            "&cThe resource pack is required!");
                    kick(player, kickMsg);
                }
            }
            case FAILED_DOWNLOAD, FAILED_RELOAD, INVALID_URL -> {
                pendingResponse.remove(player.getUniqueId());
                if (mandatory) {
                    String kickMsg = plugin.getConfig().getString("resource-pack.failed-kick-message",
                            "&cThe resource pack failed to load!");
                    kick(player, kickMsg);
                }
            }
            case ACCEPTED, DOWNLOADED -> {
                // Intermediate states - keep waiting for SUCCESSFULLY_LOADED / FAILED_*.
            }
            default -> {
                // Unknown future status - ignore.
            }
        }
    }

    private void kick(Player player, String rawMessage) {
        if (!player.isOnline()) return;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.kick(LegacyComponentSerializer.legacyAmpersand().deserialize(rawMessage));
            }
        });
    }

    /**
     * Whether we are still waiting on this player's resource pack response.
     * Useful if other parts of the plugin (e.g. /cosmetics command) want to
     * tell the player to wait instead of just failing silently.
     */
    public boolean isPending(UUID uuid) {
        return pendingResponse.contains(uuid);
    }

    /**
     * Whether the player has successfully loaded the resource pack this
     * session. When resource-pack.mandatory is true, players who reach
     * this point in the game have necessarily accepted the RP already
     * (otherwise they'd have been kicked) - but this is still useful when
     * mandatory is false, to gate /cosmetics until the RP is actually on.
     */
    public boolean hasLoadedResourcePack(UUID uuid) {
        return rpLoaded.contains(uuid);
    }
}
