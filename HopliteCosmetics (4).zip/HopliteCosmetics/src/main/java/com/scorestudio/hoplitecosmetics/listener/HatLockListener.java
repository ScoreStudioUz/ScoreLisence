package com.scorestudio.hoplitecosmetics.listener;

import com.scorestudio.hoplitecosmetics.manager.CosmeticsManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

/**
 * Makes an equipped cosmetic hat "stick" to the player: it cannot be
 * removed via normal inventory manipulation (clicking/dragging the
 * helmet slot, shift-clicking it into the main inventory, hotbar
 * swapping, etc.), cannot be dropped on the ground, and is not lost
 * on death - it stays equipped through respawn. The ONLY way to remove
 * it is the "Remove Hat" button inside the /cosmetics GUI.
 *
 * This intentionally does not touch chestplate/leggings/boots, or the
 * helmet slot when it holds a real (non-cosmetic) helmet - only items
 * tagged by {@link CosmeticsManager#getHatIdFromItem(ItemStack)} are
 * protected.
 */
public class HatLockListener implements Listener {

    private final CosmeticsManager cosmeticsManager;

    public HatLockListener(CosmeticsManager cosmeticsManager) {
        this.cosmeticsManager = cosmeticsManager;
    }

    /**
     * Whether an item is a wearable helmet-type item (leather/iron/
     * diamond/netherite/golden/chainmail/turtle helmet, or any other
     * material ending in "_HELMET"). Used to detect shift-click /
     * hotbar-swap actions that would otherwise silently replace an
     * equipped cosmetic hat with a real helmet.
     */
    private boolean isHelmetLike(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.endsWith("_HELMET") || name.equals("CARVED_PUMPKIN");
    }

    /**
     * Blocks any inventory-click interaction with the helmet slot (or
     * any click that would move the cosmetic hat item, e.g. via
     * shift-click "collect to inventory" or number-key swapping) while
     * a cosmetic hat is equipped there.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        // Case 1: the player directly clicked their own armor "helmet" slot.
        if (event.getSlotType() == org.bukkit.event.inventory.InventoryType.SlotType.ARMOR
                && event.getRawSlot() >= 0
                && event.getClickedInventory() != null
                && event.getClickedInventory().equals(player.getInventory())) {

            ItemStack helmet = player.getInventory().getHelmet();
            if (cosmeticsManager.getHatIdFromItem(helmet) != null) {
                event.setCancelled(true);
                return;
            }
        }

        // Case 2: shift-click ("collect to armor") or hotbar-swap can move
        // a clicked helmet item from elsewhere in the inventory directly
        // onto the armor slot, bypassing Case 1 entirely (the clicked slot
        // itself is wherever the helmet item currently sits, not the armor
        // row). If a cosmetic hat is currently equipped, block ANY click
        // whose resulting action targets another inventory/slot while a
        // helmet-type item is involved, to prevent it from silently
        // replacing the cosmetic hat.
        org.bukkit.event.inventory.InventoryAction action = event.getAction();
        if ((action == org.bukkit.event.inventory.InventoryAction.MOVE_TO_OTHER_INVENTORY
                || action == org.bukkit.event.inventory.InventoryAction.HOTBAR_SWAP)
                && cosmeticsManager.getHatIdFromItem(player.getInventory().getHelmet()) != null) {
            ItemStack candidate = event.getCurrentItem();
            if (candidate != null && isHelmetLike(candidate)) {
                event.setCancelled(true);
                return;
            }
        }

        // Case 3: shift-click or hotbar-swap that targets the currently
        // equipped hat item even via a different raw slot path (covers
        // edge cases like number-key "hotbar swap" onto the armor slot).
        ItemStack currentItem = event.getCurrentItem();
        if (currentItem != null && cosmeticsManager.getHatIdFromItem(currentItem) != null) {
            // The clicked stack IS a cosmetic hat (regardless of which
            // slot it's currently rendered in) - never allow moving it.
            event.setCancelled(true);
        }
    }

    /**
     * Defensive secondary check for mouse drag-split operations.
     * Note: picking the hat UP off the helmet slot is actually an
     * InventoryClickEvent (the click that puts it on the cursor), not a
     * drag - InventoryDragEvent only covers redistributing a held
     * cursor item across multiple slots. This handler exists only to
     * catch the unusual case where a previously-held cursor item
     * (somehow already a tagged hat) gets dropped back across the
     * armor row via drag; the click handler above is what does the
     * real work of preventing the hat from ever reaching the cursor.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack oldHelmet = player.getInventory().getHelmet();
        if (cosmeticsManager.getHatIdFromItem(oldHelmet) != null) {
            for (ItemStack dragged : event.getNewItems().values()) {
                if (cosmeticsManager.getHatIdFromItem(dragged) != null) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    /**
     * Blocks dropping the cosmetic hat with Q or by clicking-and-dragging
     * it out of the inventory window into the world.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerDrop(PlayerDropItemEvent event) {
        if (cosmeticsManager.getHatIdFromItem(event.getItemDrop().getItemStack()) != null) {
            event.setCancelled(true);
        }
    }

    /**
     * Blocks the F (swap hands) key from pulling the hat out of the
     * helmet slot into the off-hand.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent event) {
        ItemStack helmet = event.getPlayer().getInventory().getHelmet();
        if (cosmeticsManager.getHatIdFromItem(helmet) != null) {
            // Swapping hands does not normally touch the helmet slot, but
            // some clients/mods can trigger edge cases - block defensively
            // only if either swapped item happens to be the hat itself.
            if (cosmeticsManager.getHatIdFromItem(event.getMainHandItem()) != null
                    || cosmeticsManager.getHatIdFromItem(event.getOffHandItem()) != null) {
                event.setCancelled(true);
            }
        }
    }

    /**
     * Removes the cosmetic hat from the death drop list so it is never
     * lost on death, then re-applies it directly to the helmet slot of
     * the respawned player's inventory. We do NOT use Paper's
     * getItemsToKeep() here even though it exists for this exact
     * purpose, because it does not guarantee the kept item is restored
     * to the SAME slot (helmet) it came from - it can land anywhere in
     * the inventory. Since this hat must specifically end up back on
     * the head (not as a random inventory item), we track it ourselves
     * and place it precisely via PlayerInventory.setHelmet() on respawn.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        ItemStack helmet = player.getInventory().getHelmet();
        String hatId = cosmeticsManager.getHatIdFromItem(helmet);
        if (hatId == null) {
            return;
        }

        Iterator<ItemStack> iterator = event.getDrops().iterator();
        while (iterator.hasNext()) {
            ItemStack drop = iterator.next();
            if (cosmeticsManager.getHatIdFromItem(drop) != null) {
                iterator.remove();
            }
        }

        ItemStack hatCopy = helmet.clone();
        cosmeticsManager.rememberPendingRestore(player.getUniqueId(), hatCopy);
    }

    /**
     * Re-equips the hat that was set aside in onPlayerDeath, once the
     * player's post-respawn inventory exists to receive it.
     */
    @EventHandler(priority = EventPriority.NORMAL)
    public void onPlayerRespawn(org.bukkit.event.player.PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        cosmeticsManager.applyPendingRestore(player);
    }
}
