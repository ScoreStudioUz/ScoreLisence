package com.scorestudio.hoplitecosmetics.commands;

import com.scorestudio.hoplitecosmetics.gui.CosmeticsGUI;
import com.scorestudio.hoplitecosmetics.manager.HatManager;
import com.scorestudio.hoplitecosmetics.manager.PlayerDataManager;
import com.scorestudio.hoplitecosmetics.listener.ResourcePackListener;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class CosmeticsCommand implements CommandExecutor {

    private final Plugin plugin;
    private final HatManager hatManager;
    private final PlayerDataManager playerDataManager;
    private final ResourcePackListener resourcePackListener;

    public CosmeticsCommand(Plugin plugin, HatManager hatManager, PlayerDataManager playerDataManager,
                             ResourcePackListener resourcePackListener) {
        this.plugin = plugin;
        this.hatManager = hatManager;
        this.playerDataManager = playerDataManager;
        this.resourcePackListener = resourcePackListener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        if (!player.hasPermission("hoplitecosmetics.use")) {
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&cYou don't have permission to use this command."));
            return true;
        }

        boolean mandatory = plugin.getConfig().getBoolean("resource-pack.mandatory", true);
        if (!mandatory && !resourcePackListener.hasLoadedResourcePack(player.getUniqueId())) {
            String msg = plugin.getConfig().getString("resource-pack.not-loaded-message",
                    "&cPlease load the resource pack first!");
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
            return true;
        }

        CosmeticsGUI gui = new CosmeticsGUI(plugin, hatManager, playerDataManager, player);
        gui.open();
        return true;
    }
}
