package com.scorestudio.hoplitecosmetics.manager;

import com.scorestudio.hoplitecosmetics.model.HatDefinition;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * Loads and stores all {@link HatDefinition} entries from config.yml's
 * "hats" section. Order is preserved (LinkedHashMap) so the paginated
 * GUI lays out hats in the same order they appear in the config,
 * 45 per page.
 */
public class HatManager {

    private final Plugin plugin;
    private final Map<String, HatDefinition> hats = new LinkedHashMap<>();
    private final List<HatDefinition> orderedHats = new ArrayList<>();

    public HatManager(Plugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        hats.clear();
        orderedHats.clear();

        FileConfiguration config = plugin.getConfig();
        ConfigurationSection hatsSection = config.getConfigurationSection("hats");
        if (hatsSection == null) {
            plugin.getLogger().warning("No 'hats' section found in config.yml!");
            return;
        }

        for (String id : hatsSection.getKeys(false)) {
            ConfigurationSection section = hatsSection.getConfigurationSection(id);
            if (section == null) continue;

            try {
                String displayName = section.getString("display-name", "&fUnnamed Hat");
                int cmd = section.getInt("custom-model-data", -1);
                String materialName = section.getString("icon-material", "COAL");
                Material material = Material.matchMaterial(materialName);
                if (material == null) {
                    plugin.getLogger().warning("Invalid material '" + materialName + "' for hat '" + id + "', falling back to COAL.");
                    material = Material.COAL;
                }
                if (cmd < 0) {
                    plugin.getLogger().warning("Hat '" + id + "' has no custom-model-data set, skipping.");
                    continue;
                }

                List<String> lore = section.getStringList("lore");

                HatDefinition hat = new HatDefinition(id, displayName, cmd, material, lore);
                hats.put(id, hat);
                orderedHats.add(hat);
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "Error loading hat '" + id + "': " + ex.getMessage(), ex);
            }
        }

        plugin.getLogger().info("Loaded " + hats.size() + " cosmetic hats.");
    }

    public HatDefinition getHat(String id) {
        return hats.get(id);
    }

    public boolean exists(String id) {
        return hats.containsKey(id);
    }

    public Map<String, HatDefinition> getAllHats() {
        return hats;
    }

    /**
     * Returns all hats in stable config-file order, for paginated display.
     */
    public List<HatDefinition> getOrderedHats() {
        return orderedHats;
    }

    public int getTotalPages(int pageSize) {
        if (orderedHats.isEmpty()) return 1;
        return (int) Math.ceil(orderedHats.size() / (double) pageSize);
    }
}
