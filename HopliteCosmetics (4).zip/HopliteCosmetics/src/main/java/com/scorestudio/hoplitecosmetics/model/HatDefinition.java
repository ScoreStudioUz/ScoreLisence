package com.scorestudio.hoplitecosmetics.model;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single cosmetic hat definition loaded from config.yml.
 * Each hat maps to a specific custom_model_data value on the base
 * "coal" item, which the Hoplite Civilization resource pack renders
 * as a 3D model when worn in the helmet slot.
 *
 * Every hat carries a permission node (hoplitecosmetics.hat.<id>) that
 * is the single source of truth for whether a player can equip it.
 * Server staff grant access through LuckPerms (or any permission
 * plugin) - see CosmeticsGUI/GUIListener for where this is checked.
 */
public class HatDefinition {

    private static final String PERMISSION_PREFIX = "hoplitecosmetics.hat.";

    private final String id;
    private final String displayName;
    private final int customModelData;
    private final Material iconMaterial;
    private final List<String> lore;

    public HatDefinition(String id, String displayName, int customModelData,
                          Material iconMaterial, List<String> lore) {
        this.id = id;
        this.displayName = displayName;
        this.customModelData = customModelData;
        this.iconMaterial = iconMaterial;
        this.lore = lore;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getCustomModelData() {
        return customModelData;
    }

    public Material getIconMaterial() {
        return iconMaterial;
    }

    public List<String> getLore() {
        return lore;
    }

    /**
     * The LuckPerms-compatible permission node that gates this specific
     * hat, e.g. "hoplitecosmetics.hat.dragon_hat". Granting this node to
     * a player (or a group) via /lp user <name> permission set
     * hoplitecosmetics.hat.dragon_hat true unlocks the hat for them.
     */
    public String getPermission() {
        return PERMISSION_PREFIX + id;
    }

    /**
     * Builds the actual wearable ItemStack for this hat: an item of
     * {@link #iconMaterial} (the RP's base item, e.g. COAL) carrying the
     * custom_model_data value the resource pack expects.
     */
    public ItemStack buildHatItem() {
        ItemStack item = new ItemStack(iconMaterial, 1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setCustomModelData(customModelData);
            meta.displayName(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize(displayName)
                    .decoration(TextDecoration.ITALIC, false));
            item.setItemMeta(meta);
        }
        return item;
    }

    /**
     * Builds the GUI menu icon (with lore) for the cosmetics selection screen.
     */
    public ItemStack buildMenuIcon(boolean equipped, boolean unlocked) {
        ItemStack item = buildHatItem();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            List<Component> loreComponents = new ArrayList<>();
            for (String line : lore) {
                loreComponents.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize(line)
                        .decoration(TextDecoration.ITALIC, false));
            }
            if (!lore.isEmpty()) {
                loreComponents.add(Component.empty());
            }
            if (equipped) {
                loreComponents.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&a&l✔ Equipped")
                        .decoration(TextDecoration.ITALIC, false));
            } else if (unlocked) {
                loreComponents.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7Click to equip")
                        .decoration(TextDecoration.ITALIC, false));
            } else {
                loreComponents.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&cLocked")
                        .decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(loreComponents);
            item.setItemMeta(meta);
        }
        return item;
    }
}
