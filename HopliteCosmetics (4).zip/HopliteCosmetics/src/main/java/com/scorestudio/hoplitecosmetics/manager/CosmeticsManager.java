package com.scorestudio.hoplitecosmetics.manager;

import com.scorestudio.hoplitecosmetics.model.HatDefinition;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Equips and removes cosmetic hats by directly manipulating the player's
 * helmet armor slot. Because the hat is just a re-skinned vanilla item
 * (via custom_model_data, resolved client-side by the resource pack),
 * wearing it in the helmet slot makes it visible to every nearby player
 * automatically - no packets, no extra rendering plugin needed.
 *
 * To distinguish a cosmetic hat from a "real" helmet the player might
 * already be wearing, every cosmetic hat item carries a hidden
 * PersistentDataContainer tag (hatTagKey -> hat id).
 *
 * The hat is designed to "stick" once equipped: {@link HatLockListener}
 * blocks removing/dropping it through normal inventory interaction, and
 * this class handles carrying it across death/respawn so it is never
 * lost - the only way to remove it is the /cosmetics "Remove Hat"
 * button, which calls {@link #removeHat(Player)} directly.
 */
public class CosmeticsManager {

    private final Plugin plugin;
    private final HatManager hatManager;
    private final PlayerDataManager playerDataManager;
    private final NamespacedKey hatTagKey;

    // Holds a hat ItemStack that needs to be re-applied to a player's
    // helmet slot once their inventory exists again after respawning.
    // Populated in HatLockListener#onPlayerDeath, consumed in
    // HatLockListener#onPlayerRespawn via applyPendingRestore().
    private final Map<UUID, ItemStack> pendingDeathRestore = new ConcurrentHashMap<>();

    public CosmeticsManager(Plugin plugin, HatManager hatManager, PlayerDataManager playerDataManager) {
        this.plugin = plugin;
        this.hatManager = hatManager;
        this.playerDataManager = playerDataManager;
        this.hatTagKey = new NamespacedKey(plugin, "hoplite_cosmetic_hat");
    }

    public NamespacedKey getHatTagKey() {
        return hatTagKey;
    }

    /**
     * Returns the hat id stored on an item, or null if the item is not
     * a HopliteCosmetics hat.
     */
    public String getHatIdFromItem(ItemStack item) {
        if (item == null) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(hatTagKey, PersistentDataType.STRING);
    }

    /**
     * Whether the item currently in the player's helmet slot is a
     * HopliteCosmetics hat (as opposed to a real helmet/leather cap/etc).
     */
    public boolean isWearingCosmeticHat(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        return getHatIdFromItem(helmet) != null;
    }

    /**
     * Whether a given helmet-slot ItemStack should be considered "safe to
     * overwrite with a cosmetic hat" - true if the slot is genuinely empty
     * (null OR Material.AIR, since Bukkit/Paper inconsistently return one
     * or the other depending on call context) or already holds one of our
     * own cosmetic hats.
     */
    private boolean isSlotEmptyOrCosmetic(ItemStack item) {
        if (item == null || item.getType() == org.bukkit.Material.AIR) {
            return true;
        }
        return getHatIdFromItem(item) != null;
    }

    /**
     * Equips the given hat on the player, replacing whatever is currently
     * in the helmet slot IF that slot is empty or already holds a
     * cosmetic hat. If the player is wearing a real helmet (not a
     * cosmetic), we refuse to overwrite it and return false - per the
     * requirement that a hat already worn on the player's head (a real
     * helmet) must be removed by the player first before a cosmetic can
     * be equipped.
     */
    public boolean equip(Player player, HatDefinition hat) {
        PlayerInventory inv = player.getInventory();
        ItemStack currentHelmet = inv.getHelmet();

        if (!isSlotEmptyOrCosmetic(currentHelmet)) {
            // Player is wearing a real helmet - don't clobber it.
            return false;
        }

        ItemStack hatItem = hat.buildHatItem();
        ItemMeta meta = hatItem.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(hatTagKey, PersistentDataType.STRING, hat.getId());
            hatItem.setItemMeta(meta);
        }

        inv.setHelmet(hatItem);
        playerDataManager.setEquippedHat(player.getUniqueId(), hat.getId());
        return true;
    }

    /**
     * Removes the currently equipped cosmetic hat from the player's
     * helmet slot, if any. Does nothing if the player is wearing a real
     * helmet instead. This is the ONLY supported way to remove an
     * equipped hat - normal inventory interaction is blocked by
     * {@link HatLockListener}.
     */
    public boolean removeHat(Player player) {
        PlayerInventory inv = player.getInventory();
        ItemStack currentHelmet = inv.getHelmet();

        if (getHatIdFromItem(currentHelmet) == null) {
            return false;
        }

        inv.setHelmet(null);
        playerDataManager.setEquippedHat(player.getUniqueId(), null);
        return true;
    }

    /**
     * Re-applies a player's saved equipped hat (if any) to their helmet
     * slot. Called on join, after the resource pack has been confirmed,
     * so returning players see their cosmetic restored.
     */
    public void restoreEquippedHat(Player player) {
        String hatId = playerDataManager.getEquippedHat(player.getUniqueId());
        if (hatId == null) return;

        HatDefinition hat = hatManager.getHat(hatId);
        if (hat == null) return;

        // Only restore into an empty or already-cosmetic helmet slot.
        ItemStack currentHelmet = player.getInventory().getHelmet();
        if (!isSlotEmptyOrCosmetic(currentHelmet)) {
            return;
        }

        equip(player, hat);
    }

    /**
     * Stashes a copy of the hat the player was wearing when they died,
     * so {@link #applyPendingRestore(Player)} can put it back on their
     * helmet slot once their post-respawn inventory exists. Used by
     * {@link HatLockListener#onPlayerDeath} so the hat is never lost on
     * death, matching the requirement that it stays equipped until the
     * player removes it themselves via the menu.
     */
    public void rememberPendingRestore(UUID uuid, ItemStack hatItemCopy) {
        pendingDeathRestore.put(uuid, hatItemCopy);
    }

    /**
     * Applies and clears any pending death-restore hat for this player.
     * Safe to call even if there is nothing pending (no-op).
     */
    public void applyPendingRestore(Player player) {
        ItemStack hatItem = pendingDeathRestore.remove(player.getUniqueId());
        if (hatItem == null) return;

        PlayerInventory inv = player.getInventory();
        ItemStack currentHelmet = inv.getHelmet();
        if (!isSlotEmptyOrCosmetic(currentHelmet)) {
            // Extremely unlikely after a fresh respawn, but don't clobber
            // a real helmet if some other plugin already gave the player one.
            return;
        }

        inv.setHelmet(hatItem);
        String hatId = getHatIdFromItem(hatItem);
        if (hatId != null) {
            playerDataManager.setEquippedHat(player.getUniqueId(), hatId);
        }
    }
}
