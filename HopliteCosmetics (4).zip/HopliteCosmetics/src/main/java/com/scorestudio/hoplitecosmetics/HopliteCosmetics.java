package com.scorestudio.hoplitecosmetics;

import com.scorestudio.hoplitecosmetics.commands.CosmeticsAdminCommand;
import com.scorestudio.hoplitecosmetics.commands.CosmeticsCommand;
import com.scorestudio.hoplitecosmetics.listener.GUIListener;
import com.scorestudio.hoplitecosmetics.listener.HatLockListener;
import com.scorestudio.hoplitecosmetics.listener.ResourcePackListener;
import com.scorestudio.hoplitecosmetics.manager.CosmeticsManager;
import com.scorestudio.hoplitecosmetics.manager.HatManager;
import com.scorestudio.hoplitecosmetics.manager.PlayerDataManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * HopliteCosmetics ("ScoreCosmetics")
 * ScoreStudio | mc.uzpvp.uz
 *
 * GUI-based cosmetic hat plugin built around the ScoreCosmetics
 * resource pack. Hats are rendered via custom_model_data on a COAL
 * base item worn in the player's real helmet slot - visible to
 * everyone nearby through normal vanilla armor rendering.
 *
 * Access to each individual hat is controlled by a LuckPerms-compatible
 * permission node (hoplitecosmetics.hat.<id>) rather than an internal
 * unlock list, so server staff can manage cosmetics entirely through
 * their existing permission setup.
 *
 * Once equipped, a hat "sticks" to the player: it cannot be removed,
 * dropped, or lost on death through normal means (see HatLockListener)
 * - the only way to remove it is the /cosmetics "Remove Hat" button.
 *
 * Sends a mandatory resource pack to every player on join; once
 * accepted, players can use /cosmetics to customize their appearance.
 */
public class HopliteCosmetics extends JavaPlugin {

    private HatManager hatManager;
    private PlayerDataManager playerDataManager;
    private CosmeticsManager cosmeticsManager;
    private ResourcePackListener resourcePackListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.hatManager = new HatManager(this);
        this.playerDataManager = new PlayerDataManager(this);
        this.cosmeticsManager = new CosmeticsManager(this, hatManager, playerDataManager);
        this.resourcePackListener = new ResourcePackListener(this, cosmeticsManager, playerDataManager);

        getServer().getPluginManager().registerEvents(resourcePackListener, this);
        getServer().getPluginManager().registerEvents(
                new GUIListener(this, hatManager, playerDataManager, cosmeticsManager), this);
        getServer().getPluginManager().registerEvents(new HatLockListener(cosmeticsManager), this);

        var cosmeticsCommand = getCommand("cosmetics");
        if (cosmeticsCommand != null) {
            cosmeticsCommand.setExecutor(new CosmeticsCommand(this, hatManager, playerDataManager, resourcePackListener));
        } else {
            getLogger().severe("'/cosmetics' command not found in plugin.yml!");
        }

        var adminCommand = getCommand("cosmeticsadmin");
        if (adminCommand != null) {
            adminCommand.setExecutor(new CosmeticsAdminCommand(this, hatManager));
        } else {
            getLogger().severe("'/cosmeticsadmin' command not found in plugin.yml!");
        }

        getLogger().info("HopliteCosmetics enabled - " + hatManager.getAllHats().size() + " hats loaded.");
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) {
            playerDataManager.saveAll();
        }
        getLogger().info("HopliteCosmetics disabled, all player data saved.");
    }

    public HatManager getHatManager() {
        return hatManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public CosmeticsManager getCosmeticsManager() {
        return cosmeticsManager;
    }

    public ResourcePackListener getResourcePackListener() {
        return resourcePackListener;
    }
}
