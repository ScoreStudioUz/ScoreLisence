package com.scorestudio.hoplitecosmetics.manager;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * Handles per-player cosmetic data persistence using simple YAML files,
 * one file per player UUID, stored under plugins/HopliteCosmetics/playerdata/.
 *
 * File layout (playerdata/<uuid>.yml):
 *   equipped-hat: dragon_hat
 *
 * Which hats a player is ALLOWED to wear is no longer tracked here -
 * that is now controlled entirely by LuckPerms (or any permission
 * plugin) granting hoplitecosmetics.hat.<id> nodes. This file only
 * remembers which hat (if any) a given player currently has equipped,
 * so it can be restored across sessions and across death/respawn.
 *
 * Data is cached in memory while a player is online and flushed to disk
 * on change and on player quit, to avoid blocking I/O on every read.
 */
public class PlayerDataManager {

    private final Plugin plugin;
    private final File folder;
    private final Map<UUID, PlayerCosmeticData> cache = new ConcurrentHashMap<>();

    public PlayerDataManager(Plugin plugin) {
        this.plugin = plugin;
        String folderName = plugin.getConfig().getString("storage.folder", "playerdata");
        this.folder = new File(plugin.getDataFolder(), folderName);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

    private File fileFor(UUID uuid) {
        return new File(folder, uuid.toString() + ".yml");
    }

    /**
     * Loads a player's cosmetic data from disk into the in-memory cache.
     * Should be called on PlayerJoinEvent (async-safe: pure file I/O).
     */
    public PlayerCosmeticData load(UUID uuid) {
        File file = fileFor(uuid);
        PlayerCosmeticData data = new PlayerCosmeticData();

        if (file.exists()) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            data.equippedHat = yaml.getString("equipped-hat", null);
        }

        cache.put(uuid, data);
        return data;
    }

    public PlayerCosmeticData get(UUID uuid) {
        return cache.computeIfAbsent(uuid, this::load);
    }

    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
    }

    public void save(UUID uuid) {
        PlayerCosmeticData data = cache.get(uuid);
        if (data == null) return;

        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("equipped-hat", data.equippedHat);

        try {
            yaml.save(fileFor(uuid));
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Error saving player data (" + uuid + "): " + ex.getMessage(), ex);
        }
    }

    public void saveAll() {
        for (UUID uuid : cache.keySet()) {
            save(uuid);
        }
    }

    public String getEquippedHat(UUID uuid) {
        return get(uuid).equippedHat;
    }

    public void setEquippedHat(UUID uuid, String hatId) {
        PlayerCosmeticData data = get(uuid);
        data.equippedHat = hatId;
        save(uuid);
    }

    /**
     * Simple in-memory holder for a single player's cosmetic state.
     */
    public static class PlayerCosmeticData {
        public String equippedHat = null;
    }
}
