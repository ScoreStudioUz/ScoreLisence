package com.scorestudio.hoplitecosmetics.listener;

import com.scorestudio.hoplitecosmetics.gui.CosmeticsGUI;
import com.scorestudio.hoplitecosmetics.manager.CosmeticsManager;
import com.scorestudio.hoplitecosmetics.manager.HatManager;
import com.scorestudio.hoplitecosmetics.manager.PlayerDataManager;
import com.scorestudio.hoplitecosmetics.model.HatDefinition;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.plugin.Plugin;

/**
 * Handles clicks inside the cosmetics hat GUI: page navigation,
 * removing the equipped hat, and equipping a hat. Access to each hat
 * is gated by its LuckPerms-compatible permission node
 * (hoplitecosmetics.hat.<id>) - there is no separate "unlock list"
 * anymore, the permission node is the single source of truth.
 */
public class GUIListener implements Listener {

    private final Plugin plugin;
    private final HatManager hatManager;
    private final PlayerDataManager playerDataManager;
    private final CosmeticsManager cosmeticsManager;

    public GUIListener(Plugin plugin, HatManager hatManager, PlayerDataManager playerDataManager,
                        CosmeticsManager cosmeticsManager) {
        this.plugin = plugin;
        this.hatManager = hatManager;
        this.playerDataManager = playerDataManager;
        this.cosmeticsManager = cosmeticsManager;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof CosmeticsGUI gui) {
            handleHatsClick(event, gui);
        }
    }

    private void handleHatsClick(InventoryClickEvent event, CosmeticsGUI gui) {
        // Always cancel clicks inside the cosmetics menu - it's a pure
        // selection UI, not a real inventory players should be able to
        // take items from.
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) {
            return;
        }

        // Navigation: previous page.
        if (slot == CosmeticsGUI.PREV_PAGE_SLOT && gui.getPage() > 0) {
            gui.setPage(gui.getPage() - 1);
            return;
        }

        // Navigation: next page.
        if (slot == CosmeticsGUI.NEXT_PAGE_SLOT) {
            gui.setPage(gui.getPage() + 1);
            return;
        }

        // Remove currently equipped hat.
        if (slot == CosmeticsGUI.REMOVE_HAT_SLOT) {
            boolean removed = cosmeticsManager.removeHat(player);
            if (removed) {
                String msg = plugin.getConfig().getString("messages.hat-removed", "&7Hat removed.");
                player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
                gui.refresh();
            }
            return;
        }

        // Anything else outside the 0-44 hat grid (filler, page indicator) is a no-op.
        if (slot < 0 || slot >= CosmeticsGUI.HATS_PER_PAGE) {
            return;
        }

        String hatId = gui.getHatIdAt(slot);
        if (hatId == null) {
            return; // filler / empty slot
        }

        HatDefinition hat = hatManager.getHat(hatId);
        if (hat == null) {
            return;
        }

        if (!player.hasPermission(hat.getPermission())) {
            String msg = plugin.getConfig().getString("messages.no-permission", "&cThis hat is not unlocked for you.");
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
            return;
        }

        boolean equipped = cosmeticsManager.equip(player, hat);
        if (equipped) {
            String msg = plugin.getConfig().getString("messages.hat-equipped", "&aYou equipped &6%hat%&a!")
                    .replace("%hat%", hat.getDisplayName());
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
            gui.refresh();
        } else {
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&cRemove your real helmet first!"));
        }
    }
}
