package com.scorestudio.hoplitecosmetics.commands;

import com.scorestudio.hoplitecosmetics.manager.HatManager;
import com.scorestudio.hoplitecosmetics.model.HatDefinition;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

/**
 * Admin commands for HopliteCosmetics. Unlocking specific hats for
 * players is no longer done here - it's handled entirely by granting
 * permission nodes through LuckPerms (or any permission plugin), e.g.:
 *
 *   /lp user <player> permission set hoplitecosmetics.hat.dragon_hat true
 *
 * This command only covers config reloading and a convenience listing
 * of every hat's id + permission node, so server staff don't have to
 * cross-reference config.yml by hand when granting permissions.
 */
public class CosmeticsAdminCommand implements CommandExecutor {

    private final Plugin plugin;
    private final HatManager hatManager;

    public CosmeticsAdminCommand(Plugin plugin, HatManager hatManager) {
        this.plugin = plugin;
        this.hatManager = hatManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hoplitecosmetics.admin")) {
            sender.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&cYou don't have permission to use this command."));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                hatManager.load();
                String msg = plugin.getConfig().getString("messages.reload-success", "&aConfig reloaded.");
                sender.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(msg));
            }
            case "listhats" -> handleListHats(sender, args);
            default -> sendUsage(sender);
        }
        return true;
    }

    private void handleListHats(CommandSender sender, String[] args) {
        String filter = args.length > 1 ? args[1].toLowerCase() : null;

        sender.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                .deserialize("&6&lHat permission nodes:"));

        int shown = 0;
        for (HatDefinition hat : hatManager.getAllHats().values()) {
            if (filter != null && !hat.getId().toLowerCase().contains(filter)
                    && !hat.getDisplayName().toLowerCase().contains(filter)) {
                continue;
            }
            sender.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&7" + hat.getId() + " &8-> &f" + hat.getPermission()));
            shown++;
            if (shown >= 50) {
                sender.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&8... and more. Use a filter: /cosmeticsadmin listhats <text>"));
                break;
            }
        }

        if (shown == 0) {
            sender.sendMessage(LegacyComponentSerializer.legacyAmpersand()
                    .deserialize("&cNo hats matched that filter."));
        }
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(
                "&6&lHopliteCosmetics Admin:\n" +
                        "&7/cosmeticsadmin reload\n" +
                        "&7/cosmeticsadmin listhats [filter] &8- show permission nodes\n" +
                        "&8Grant hats via LuckPerms, e.g.:\n" +
                        "&8/lp user <player> permission set hoplitecosmetics.hat.<id> true"
        ));
    }
}
