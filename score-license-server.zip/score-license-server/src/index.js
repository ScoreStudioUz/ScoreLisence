'use strict';
require('dotenv').config();

const express    = require('express');
const helmet     = require('helmet');
const morgan     = require('morgan');
const path       = require('path');
const rateLimit  = require('express-rate-limit');
const session    = require('express-session');
const pgSession  = require('connect-pg-simple')(session);
const pool       = require('./db/pool');

const verifyRouter = require('./routes/verify');
const adminRouter  = require('./routes/admin');

const app = express();

// ── Security headers ───────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.set('trust proxy', 1);

// ── Request logging ────────────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('[:date[iso]] :method :url :status :response-time ms'));
}

// ── Body parser ────────────────────────────────────────────────────────────
app.use(express.json({ limit: '16kb' }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));

// ── Session (stored in Postgres) ───────────────────────────────────────────
app.use(session({
  store: new pgSession({ pool, tableName: 'session' }),
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 8 * 60 * 60 * 1000, // 8 hours
    sameSite: 'strict'
  }
}));

// ── Rate limiters ──────────────────────────────────────────────────────────
const verifyLimiter = rateLimit({
  windowMs: 60 * 1000,  // 1 minute
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests' },
  keyGenerator: (req) => req.ip,
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts' },
  keyGenerator: (req) => req.ip,
  skipSuccessfulRequests: true,
});

// ── Health check ───────────────────────────────────────────────────────────
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.status(200).json({ status: 'ok', ts: Math.floor(Date.now() / 1000) });
  } catch {
    res.status(503).json({ status: 'db_error' });
  }
});

// ── API: Verify endpoint ───────────────────────────────────────────────────
app.use('/api/v1/verify', verifyLimiter, verifyRouter);

// ── Admin login rate limit ─────────────────────────────────────────────────
app.use('/admin/api/login', loginLimiter);

// ── Admin routes (API + static) ────────────────────────────────────────────
app.use('/admin', adminRouter);

// ── Serve admin frontend ───────────────────────────────────────────────────
app.use('/admin', express.static(path.join(__dirname, '../admin/public')));

// Redirect /admin to /admin/index.html
app.get('/admin', (req, res) => res.redirect('/admin/index.html'));

// ── 404 fallback ───────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// ── Global error handler ───────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start ──────────────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '3000');
app.listen(PORT, () => {
  console.log(`[server] Score License Server running on port ${PORT}`);
  console.log(`[server] Admin panel: http://localhost:${PORT}/admin`);
});

module.exports = app;
