'use strict';
const router = require('express').Router();
const bcrypt = require('bcrypt');
const pool = require('../db/pool');
const { generateLicenseKey } = require('../utils/crypto');
const { requireAuth } = require('../middleware/auth');

// ════════════════════════════════════════════════════════════
//  AUTH
// ════════════════════════════════════════════════════════════

// POST /admin/api/login
router.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing credentials' });

  const result = await pool.query('SELECT id, password_hash FROM admins WHERE username=$1', [username]);
  const admin = result.rows[0];
  if (!admin) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, admin.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  req.session.adminId = admin.id;
  req.session.username = username;
  res.json({ ok: true });
});

// POST /admin/api/logout
router.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// All routes below require auth
router.use(requireAuth);

// GET /admin/api/me
router.get('/api/me', (req, res) => {
  res.json({ username: req.session.username });
});

// ════════════════════════════════════════════════════════════
//  DASHBOARD
// ════════════════════════════════════════════════════════════

router.get('/api/dashboard', async (req, res) => {
  const [total, active, expiring, checks24h] = await Promise.all([
    pool.query(`SELECT COUNT(*) FROM licenses`),
    pool.query(`SELECT COUNT(*) FROM licenses WHERE status='active' AND expiry_at > NOW()`),
    pool.query(`SELECT COUNT(*) FROM licenses WHERE status='active' AND expiry_at BETWEEN NOW() AND NOW() + INTERVAL '7 days'`),
    pool.query(`SELECT COUNT(*) FROM logs WHERE created_at > NOW() - INTERVAL '24 hours'`),
  ]);
  res.json({
    total:     parseInt(total.rows[0].count),
    active:    parseInt(active.rows[0].count),
    expiring:  parseInt(expiring.rows[0].count),
    checks24h: parseInt(checks24h.rows[0].count),
  });
});

// ════════════════════════════════════════════════════════════
//  LICENSES
// ════════════════════════════════════════════════════════════

// GET /admin/api/licenses?page=1&status=active&plugin=ScorePvP&search=owner
router.get('/api/licenses', async (req, res) => {
  const page  = Math.max(1, parseInt(req.query.page) || 1);
  const limit = 25;
  const offset = (page - 1) * limit;

  let where = ['1=1'];
  const params = [];

  if (req.query.status) {
    params.push(req.query.status);
    where.push(`status = $${params.length}`);
  }
  if (req.query.plugin) {
    params.push(`%${req.query.plugin}%`);
    where.push(`plugins::text ILIKE $${params.length}`);
  }
  if (req.query.search) {
    params.push(`%${req.query.search}%`);
    where.push(`(key ILIKE $${params.length} OR owner_name ILIKE $${params.length} OR owner_contact ILIKE $${params.length})`);
  }

  const whereStr = where.join(' AND ');

  const [rows, countRes] = await Promise.all([
    pool.query(
      `SELECT id, key, owner_name, owner_contact, plugins, hwids, max_servers,
              level, status, expiry_at, last_seen_at, last_ip, check_count, created_at
       FROM licenses WHERE ${whereStr}
       ORDER BY created_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, limit, offset]
    ),
    pool.query(`SELECT COUNT(*) FROM licenses WHERE ${whereStr}`, params),
  ]);

  res.json({
    licenses: rows.rows,
    total:    parseInt(countRes.rows[0].count),
    page, limit
  });
});

// GET /admin/api/licenses/:id
router.get('/api/licenses/:id', async (req, res) => {
  const r = await pool.query('SELECT * FROM licenses WHERE id=$1', [req.params.id]);
  if (!r.rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json(r.rows[0]);
});

// POST /admin/api/licenses — create new license
router.post('/api/licenses', async (req, res) => {
  const { owner_name, owner_contact, plugins, max_servers, level, expiry_at } = req.body;
  if (!expiry_at) return res.status(400).json({ error: 'expiry_at required' });

  // Generate unique key
  let key, attempts = 0;
  while (attempts++ < 10) {
    key = generateLicenseKey();
    const exists = await pool.query('SELECT id FROM licenses WHERE key=$1', [key]);
    if (!exists.rows[0]) break;
  }

  const r = await pool.query(
    `INSERT INTO licenses (key, owner_name, owner_contact, plugins, max_servers, level, status, expiry_at)
     VALUES ($1,$2,$3,$4::jsonb,$5,$6,'active',$7)
     RETURNING *`,
    [
      key,
      owner_name || null,
      owner_contact || null,
      JSON.stringify(Array.isArray(plugins) ? plugins : []),
      parseInt(max_servers) || 1,
      parseInt(level) || 1,
      expiry_at
    ]
  );
  res.status(201).json(r.rows[0]);
});

// PATCH /admin/api/licenses/:id — update license fields
router.patch('/api/licenses/:id', async (req, res) => {
  const allowed = ['owner_name','owner_contact','plugins','max_servers','level','status','expiry_at'];
  const sets = [];
  const params = [];

  for (const field of allowed) {
    if (req.body[field] !== undefined) {
      params.push(
        field === 'plugins' ? JSON.stringify(req.body[field]) : req.body[field]
      );
      sets.push(`${field} = $${params.length}${field === 'plugins' ? '::jsonb' : ''}`);
    }
  }

  if (!sets.length) return res.status(400).json({ error: 'Nothing to update' });

  params.push(req.params.id);
  const r = await pool.query(
    `UPDATE licenses SET ${sets.join(',')} WHERE id=$${params.length} RETURNING *`,
    params
  );
  if (!r.rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json(r.rows[0]);
});

// POST /admin/api/licenses/:id/reset-hwids
router.post('/api/licenses/:id/reset-hwids', async (req, res) => {
  const r = await pool.query(
    `UPDATE licenses SET hwids='[]'::jsonb WHERE id=$1 RETURNING id, key`,
    [req.params.id]
  );
  if (!r.rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true, key: r.rows[0].key });
});

// DELETE /admin/api/licenses/:id
router.delete('/api/licenses/:id', async (req, res) => {
  await pool.query('DELETE FROM licenses WHERE id=$1', [req.params.id]);
  res.json({ ok: true });
});

// ════════════════════════════════════════════════════════════
//  LOGS
// ════════════════════════════════════════════════════════════

router.get('/api/logs', async (req, res) => {
  const page  = Math.max(1, parseInt(req.query.page) || 1);
  const limit = 50;
  const offset = (page - 1) * limit;

  let where = ['1=1'];
  const params = [];

  if (req.query.result) {
    params.push(req.query.result);
    where.push(`result=$${params.length}`);
  }
  if (req.query.plugin) {
    params.push(req.query.plugin);
    where.push(`plugin=$${params.length}`);
  }
  if (req.query.key) {
    params.push(`%${req.query.key}%`);
    where.push(`key ILIKE $${params.length}`);
  }
  if (req.query.date_from) {
    params.push(req.query.date_from);
    where.push(`created_at >= $${params.length}`);
  }
  if (req.query.date_to) {
    params.push(req.query.date_to);
    where.push(`created_at <= $${params.length}`);
  }

  const whereStr = where.join(' AND ');
  const [rows, countRes] = await Promise.all([
    pool.query(
      `SELECT id, key, plugin, ip, hwid, result, message, created_at
       FROM logs WHERE ${whereStr}
       ORDER BY created_at DESC
       LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, limit, offset]
    ),
    pool.query(`SELECT COUNT(*) FROM logs WHERE ${whereStr}`, params),
  ]);

  res.json({ logs: rows.rows, total: parseInt(countRes.rows[0].count), page, limit });
});

// ════════════════════════════════════════════════════════════
//  SETTINGS
// ════════════════════════════════════════════════════════════

// POST /admin/api/settings/change-password
router.post('/api/settings/change-password', async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password) return res.status(400).json({ error: 'Missing fields' });
  if (new_password.length < 8) return res.status(400).json({ error: 'Password too short (min 8)' });

  const r = await pool.query('SELECT password_hash FROM admins WHERE id=$1', [req.session.adminId]);
  const admin = r.rows[0];
  if (!admin) return res.status(401).json({ error: 'Not found' });

  const ok = await bcrypt.compare(current_password, admin.password_hash);
  if (!ok) return res.status(401).json({ error: 'Wrong current password' });

  const hash = await bcrypt.hash(new_password, 12);
  await pool.query('UPDATE admins SET password_hash=$1 WHERE id=$2', [hash, req.session.adminId]);
  res.json({ ok: true });
});

// GET /admin/api/settings/hmac-secret (masked)
router.get('/api/settings/hmac-secret', (req, res) => {
  const secret = process.env.HMAC_SECRET || '';
  const masked = secret.slice(0, 8) + '****' + secret.slice(-8);
  res.json({ masked });
});

module.exports = router;
