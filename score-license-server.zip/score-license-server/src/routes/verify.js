'use strict';
const router = require('express').Router();
const { body, validationResult } = require('express-validator');
const pool = require('../db/pool');
const {
  hmac, safeEqual,
  buildRequestSigData, buildResponseSigData
} = require('../utils/crypto');
const { checkAndStore } = require('../utils/nonceStore');
const { logVerification } = require('../utils/logger');

const TIMESTAMP_DRIFT_SEC = 300; // ±5 minutes

// Input validation rules
const verifyValidation = [
  body('plugin').isString().trim().notEmpty().isLength({ max: 64 }),
  body('key').isString().trim().notEmpty().isLength({ min: 20, max: 24 }),
  body('hwid').isString().trim().notEmpty().isLength({ max: 128 }),
  body('ip').optional().isString().trim().isLength({ max: 64 }),
  body('nonce').isString().trim().isLength({ min: 64, max: 64 }).matches(/^[0-9a-f]+$/i),
  body('ts').isInt({ min: 1_000_000_000, max: 9_999_999_999 }),
];

// Helper: send invalid response
async function replyInvalid(res, { key, plugin, ip, hwid }, result, message) {
  await logVerification({ key, plugin, ip, hwid, result, message });
  return res.status(200).json({ valid: false, expiry: 0, level: 0, nonce: '', message });
}

// Helper: send 401
async function reply401(res, { key, plugin, ip, hwid }, result, message) {
  await logVerification({ key, plugin, ip, hwid, result, message });
  return res.status(401).json({ error: message });
}

/**
 * POST /api/v1/verify
 */
router.post('/', verifyValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: 'Invalid request body', details: errors.array() });
  }

  const { plugin, key, hwid, nonce, ts } = req.body;
  const ip = req.body.ip || req.ip || '';

  // ── 1. Verify request signature ─────────────────────────────────────────
  const clientSig = req.headers['x-signature'];
  if (!clientSig || typeof clientSig !== 'string') {
    return reply401(res, { key, plugin, ip, hwid }, 'badsig', 'Missing X-Signature header');
  }

  const expectedSig = hmac(buildRequestSigData({ plugin, key, hwid, ip: req.body.ip ?? '', nonce, ts }));
  if (!safeEqual(clientSig, expectedSig)) {
    return reply401(res, { key, plugin, ip, hwid }, 'badsig', 'Invalid signature');
  }

  // ── 2. Timestamp anti-replay ─────────────────────────────────────────────
  const serverNow = Math.floor(Date.now() / 1000);
  if (Math.abs(serverNow - ts) > TIMESTAMP_DRIFT_SEC) {
    return reply401(res, { key, plugin, ip, hwid }, 'replay', 'Timestamp out of window');
  }

  // ── 3. Nonce anti-replay ──────────────────────────────────────────────────
  const freshNonce = await checkAndStore(nonce);
  if (!freshNonce) {
    return reply401(res, { key, plugin, ip, hwid }, 'replay', 'Nonce already used');
  }

  // ── 4. Database lookup ────────────────────────────────────────────────────
  let license;
  try {
    const result = await pool.query(
      `SELECT id, key, plugins, hwids, max_servers, level, status, expiry_at
       FROM licenses WHERE key = $1 LIMIT 1`,
      [key]
    );
    license = result.rows[0];
  } catch (err) {
    console.error('[verify] DB error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }

  if (!license) {
    return replyInvalid(res, { key, plugin, ip, hwid }, 'notfound', 'License key not found');
  }

  // ── 5. Status checks ──────────────────────────────────────────────────────
  if (license.status !== 'active') {
    return replyInvalid(res, { key, plugin, ip, hwid }, 'suspended', 'License suspended');
  }

  const expiryTs = Math.floor(new Date(license.expiry_at).getTime() / 1000);
  if (serverNow > expiryTs) {
    return replyInvalid(res, { key, plugin, ip, hwid }, 'expired', 'License expired');
  }

  // ── 6. Plugin check ───────────────────────────────────────────────────────
  const allowedPlugins = Array.isArray(license.plugins) ? license.plugins : [];
  if (!allowedPlugins.includes(plugin)) {
    return replyInvalid(res, { key, plugin, ip, hwid }, 'invalid', 'Plugin not licensed');
  }

  // ── 7. HWID binding ───────────────────────────────────────────────────────
  const hwids = Array.isArray(license.hwids) ? license.hwids : [];
  const maxServers = license.max_servers || 1;

  if (!hwids.includes(hwid)) {
    if (hwids.length >= maxServers) {
      return replyInvalid(res, { key, plugin, ip, hwid }, 'invalid', 'Max servers reached');
    }
    // Bind new HWID
    hwids.push(hwid);
    await pool.query(
      `UPDATE licenses SET hwids = $1::jsonb WHERE id = $2`,
      [JSON.stringify(hwids), license.id]
    );
  }

  // ── 8. Update last_seen, ip, check_count ─────────────────────────────────
  await pool.query(
    `UPDATE licenses
     SET last_seen_at = NOW(), last_ip = $1, check_count = check_count + 1
     WHERE id = $2`,
    [ip, license.id]
  );

  // ── 9. Build and sign response ────────────────────────────────────────────
  const payload = {
    valid:   true,
    expiry:  expiryTs,
    level:   license.level,
    nonce:   nonce,
    message: 'OK'
  };

  const responseSig = hmac(buildResponseSigData(payload));
  res.setHeader('X-Signature', responseSig);

  await logVerification({ key, plugin, ip, hwid, result: 'valid', message: 'OK' });
  return res.status(200).json(payload);
});

module.exports = router;
