'use strict';
require('dotenv').config();
const bcrypt = require('bcrypt');
const pool = require('./pool');

async function seed() {
  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD;
  if (!password) {
    console.error('Set ADMIN_PASSWORD in .env before seeding.');
    process.exit(1);
  }
  const hash = await bcrypt.hash(password, 12);
  await pool.query(
    `INSERT INTO admins (username, password_hash)
     VALUES ($1, $2)
     ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash`,
    [username, hash]
  );
  console.log(`[seed] Admin '${username}' created/updated.`);
  await pool.end();
}

seed().catch(err => {
  console.error('[seed] FAILED:', err.message);
  process.exit(1);
});
