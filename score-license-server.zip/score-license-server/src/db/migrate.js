'use strict';
require('dotenv').config();
const pool = require('./pool');

const SQL = `
-- Admins table
CREATE TABLE IF NOT EXISTS admins (
  id          SERIAL PRIMARY KEY,
  username    VARCHAR(64) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Licenses table
CREATE TABLE IF NOT EXISTS licenses (
  id              SERIAL PRIMARY KEY,
  key             VARCHAR(24) UNIQUE NOT NULL,
  owner_name      VARCHAR(128),
  owner_contact   VARCHAR(256),
  plugins         JSONB NOT NULL DEFAULT '[]',
  hwids           JSONB NOT NULL DEFAULT '[]',
  max_servers     INT NOT NULL DEFAULT 1,
  level           INT NOT NULL DEFAULT 1,
  status          VARCHAR(16) NOT NULL DEFAULT 'active',
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  expiry_at       TIMESTAMPTZ NOT NULL,
  last_seen_at    TIMESTAMPTZ,
  last_ip         VARCHAR(64),
  check_count     BIGINT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_licenses_key    ON licenses(key);
CREATE INDEX IF NOT EXISTS idx_licenses_status ON licenses(status);

-- Nonce store for replay protection (TTL enforced by cleanup job)
CREATE TABLE IF NOT EXISTS nonces (
  nonce       VARCHAR(128) PRIMARY KEY,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_nonces_created ON nonces(created_at);

-- Verification logs
CREATE TABLE IF NOT EXISTS logs (
  id          BIGSERIAL PRIMARY KEY,
  key         VARCHAR(24),
  plugin      VARCHAR(128),
  ip          VARCHAR(64),
  hwid        VARCHAR(128),
  result      VARCHAR(16) NOT NULL,
  message     TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logs_created ON logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_logs_key     ON logs(key);
CREATE INDEX IF NOT EXISTS idx_logs_result  ON logs(result);

-- Session store for connect-pg-simple
CREATE TABLE IF NOT EXISTS session (
  sid    VARCHAR NOT NULL COLLATE "default",
  sess   JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL,
  PRIMARY KEY (sid)
);
CREATE INDEX IF NOT EXISTS idx_session_expire ON session(expire);
`;

async function migrate() {
  const client = await pool.connect();
  try {
    console.log('[migrate] Running migrations...');
    await client.query(SQL);
    console.log('[migrate] Done.');
  } finally {
    client.release();
    await pool.end();
  }
}

migrate().catch(err => {
  console.error('[migrate] FAILED:', err.message);
  process.exit(1);
});
