'use strict';
const pool = require('../db/pool');

/**
 * result: 'valid' | 'invalid' | 'badsig' | 'expired' | 'suspended' | 'replay' | 'notfound'
 */
async function logVerification({ key, plugin, ip, hwid, result, message }) {
  try {
    await pool.query(
      `INSERT INTO logs (key, plugin, ip, hwid, result, message, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, NOW())`,
      [key || null, plugin || null, ip || null, hwid || null, result, message || null]
    );
  } catch (err) {
    console.error('[logger] Failed to write log:', err.message);
  }
}

module.exports = { logVerification };
