'use strict';
const pool = require('../db/pool');

const NONCE_TTL_MS = 10 * 60 * 1000; // 10 minutes

// In-memory fast-path set (also backed by DB for multi-instance safety)
const memCache = new Map(); // nonce -> expireAt (ms)

/**
 * Check nonce not seen before, then store it.
 * Returns true if nonce is fresh (first use), false if replay.
 */
async function checkAndStore(nonce) {
  const now = Date.now();
  const expireAt = now + NONCE_TTL_MS;

  // 1. Fast in-memory check
  if (memCache.has(nonce)) return false;

  // 2. DB check + insert (unique constraint handles race)
  const client = await pool.connect();
  try {
    const res = await client.query(
      `INSERT INTO nonces (nonce, created_at)
       VALUES ($1, NOW())
       ON CONFLICT (nonce) DO NOTHING
       RETURNING nonce`,
      [nonce]
    );
    if (res.rowCount === 0) return false; // already existed
  } finally {
    client.release();
  }

  // Store in memory
  memCache.set(nonce, expireAt);
  return true;
}

/**
 * Periodic cleanup: remove expired nonces from memory and DB.
 * Called every 5 minutes.
 */
function cleanup() {
  const now = Date.now();
  for (const [nonce, exp] of memCache.entries()) {
    if (exp < now) memCache.delete(nonce);
  }
  // DB cleanup
  pool.query(`DELETE FROM nonces WHERE created_at < NOW() - INTERVAL '10 minutes'`)
    .catch(err => console.error('[nonce cleanup]', err.message));
}

setInterval(cleanup, 5 * 60 * 1000);

module.exports = { checkAndStore };
