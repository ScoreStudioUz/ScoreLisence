'use strict';
const crypto = require('crypto');

const HMAC_SECRET = process.env.HMAC_SECRET;
if (!HMAC_SECRET) throw new Error('HMAC_SECRET not set in environment');

/**
 * Compute HMAC-SHA256 and return hex string.
 */
function hmac(data) {
  return crypto.createHmac('sha256', HMAC_SECRET).update(data).digest('hex');
}

/**
 * Constant-time hex string comparison.
 */
function safeEqual(a, b) {
  try {
    const bufA = Buffer.from(a, 'hex');
    const bufB = Buffer.from(b, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

/**
 * Build request signature string:
 * plugin|key|hwid|ip|nonce|ts
 */
function buildRequestSigData({ plugin, key, hwid, ip, nonce, ts }) {
  return [plugin, key, hwid, ip ?? '', nonce, String(ts)].join('|');
}

/**
 * Build response signature string:
 * valid_bit|expiry|level|nonce
 */
function buildResponseSigData({ valid, expiry, level, nonce }) {
  return [(valid ? '1' : '0'), String(expiry), String(level), nonce].join('|');
}

/**
 * Generate a license key in format SCORE-XXXX-XXXX-XXXX-XXXX
 * Uses 16 random bytes → 32 hex chars → split into 4 groups of 4 uppercase alphanum.
 */
function generateLicenseKey() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // unambiguous chars
  let key = 'SCORE';
  for (let g = 0; g < 4; g++) {
    key += '-';
    const bytes = crypto.randomBytes(4);
    for (let i = 0; i < 4; i++) {
      key += chars[bytes[i] % chars.length];
    }
  }
  return key; // e.g. SCORE-AB3K-7XQP-R2NM-YH4W
}

/**
 * Generate a random 64-char hex nonce (32 bytes).
 */
function generateNonce() {
  return crypto.randomBytes(32).toString('hex');
}

module.exports = { hmac, safeEqual, buildRequestSigData, buildResponseSigData, generateLicenseKey, generateNonce };
