# Score License Server

Backend license verification server for ScoreWorld Minecraft plugins.

---

## Quick Start (Docker — recommended)

```bash
# 1. Copy env file and fill in values
cp .env.example .env
nano .env

# 2. Generate secrets
openssl rand -hex 32   # paste as HMAC_SECRET
openssl rand -hex 32   # paste as SESSION_SECRET

# 3. Start
docker-compose up -d

# Admin panel: http://localhost:3000/admin
```

---

## Manual Setup (no Docker)

### Requirements
- Node.js 18+
- PostgreSQL 14+

### Steps

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your values

# Run migrations
npm run migrate

# Create first admin
npm run seed-admin

# Start server
npm start
```

---

## Environment Variables

| Variable         | Description                                        | Required |
|------------------|----------------------------------------------------|----------|
| `PORT`           | HTTP port (default: 3000)                          | No       |
| `DB_URL`         | Full postgres connection URL                       | Yes      |
| `HMAC_SECRET`    | 64-char hex secret for HMAC signing                | Yes      |
| `SESSION_SECRET` | Random secret for session encryption               | Yes      |
| `ADMIN_USERNAME` | Admin login username                               | Yes      |
| `ADMIN_PASSWORD` | Admin login password                               | Yes      |

Generate secrets:
```bash
openssl rand -hex 32
```

---

## API

### `POST /api/v1/verify`

Plugin calls this every 5 minutes.

**Request body:**
```json
{
  "plugin": "ScorePvP",
  "key":    "SCORE-XXXX-XXXX-XXXX-XXXX",
  "hwid":   "ab12cd34ef56",
  "ip":     "1.2.3.4",
  "nonce":  "<64 hex chars>",
  "ts":     1730000000
}
```

**Request header:**
```
X-Signature: hex(HMAC_SHA256(SECRET, "plugin|key|hwid|ip|nonce|ts"))
```

**Response (200):**
```json
{
  "valid":   true,
  "expiry":  1730000000,
  "level":   1,
  "nonce":   "<echoed nonce>",
  "message": "OK"
}
```

**Response header:**
```
X-Signature: hex(HMAC_SHA256(SECRET, "valid_bit|expiry|level|nonce"))
```

**Error codes:**
- `401` — invalid signature or replay attack
- `200 valid:false` — key not found / expired / suspended / wrong plugin

### `GET /health`
Returns `{"status":"ok"}` if server and DB are up.

---

## Admin Panel

`http://your-server:3000/admin`

Features:
- **Dashboard** — total keys, active, expiring soon, checks in last 24h
- **Licenses** — create, edit, suspend, delete, reset HWID bindings, filter/search
- **Logs** — verification history with filters by result, plugin, key, date
- **Settings** — change admin password, view masked HMAC secret

---

## Plugin Integration (Java example)

```java
// Build request
String nonce = generateHex(32); // 64-char hex
long ts = System.currentTimeMillis() / 1000;
String ip = ""; // optional

String sigData = String.join("|", plugin, key, hwid, ip, nonce, String.valueOf(ts));
String sig = hmacSha256Hex(HMAC_SECRET, sigData);

// POST to https://your-server/api/v1/verify
// Set header X-Signature: sig

// Verify response:
// 1. Check response X-Signature = HMAC("valid_bit|expiry|level|nonce")
// 2. Use response.valid and response.level
```

---

## Security Notes

- `HMAC_SECRET` is baked into the plugin JAR. Keep it secret.
- Rotate HMAC_SECRET by updating .env and recompiling plugins.
- Run behind HTTPS (nginx + Let's Encrypt) in production.
- Rate limiting: 60 req/min per IP on `/api/v1/verify`, 10 login attempts per 15min.
