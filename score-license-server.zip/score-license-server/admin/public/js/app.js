'use strict';

// ── State ────────────────────────────────────────────────────────────────────
let licPage = 1, logPage = 1;
let searchTimer = null;
let editingLicId = null;

// ── API helper ───────────────────────────────────────────────────────────────
async function api(method, path, body) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin'
  };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch('/admin' + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

// ── Init ─────────────────────────────────────────────────────────────────────
async function init() {
  try {
    const me = await api('GET', '/api/me');
    document.getElementById('sidebar-user').textContent = me.username;
    showApp();
    navigate('dashboard');
  } catch {
    showLogin();
  }
}

function showLogin() {
  document.getElementById('login-screen').classList.remove('hidden');
  document.getElementById('app').classList.add('hidden');
}
function showApp() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('app').classList.remove('hidden');
}

// ── Login ────────────────────────────────────────────────────────────────────
document.getElementById('login-btn').addEventListener('click', doLogin);
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !document.getElementById('login-screen').classList.contains('hidden')) doLogin();
});

async function doLogin() {
  const btn = document.getElementById('login-btn');
  const errEl = document.getElementById('login-error');
  errEl.classList.add('hidden');
  btn.disabled = true; btn.textContent = 'Signing in…';
  try {
    await api('POST', '/api/login', {
      username: document.getElementById('login-user').value.trim(),
      password: document.getElementById('login-pass').value
    });
    const me = await api('GET', '/api/me');
    document.getElementById('sidebar-user').textContent = me.username;
    showApp();
    navigate('dashboard');
  } catch (e) {
    errEl.textContent = e.message;
    errEl.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = 'Sign In';
  }
}

// ── Logout ───────────────────────────────────────────────────────────────────
document.getElementById('logout-btn').addEventListener('click', async () => {
  await api('POST', '/api/logout');
  showLogin();
});

// ── Navigation ────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(el => {
  el.addEventListener('click', e => {
    e.preventDefault();
    navigate(el.dataset.page);
  });
});

function navigate(page) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  document.getElementById('page-' + page).classList.remove('hidden');

  if (page === 'dashboard') loadDashboard();
  if (page === 'licenses')  { licPage = 1; loadLicenses(); }
  if (page === 'logs')      { logPage = 1; loadLogs(); }
  if (page === 'settings')  loadSettings();
}

// ── Dashboard ────────────────────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const d = await api('GET', '/api/dashboard');
    document.getElementById('stat-total').textContent    = d.total;
    document.getElementById('stat-active').textContent   = d.active;
    document.getElementById('stat-expiring').textContent = d.expiring;
    document.getElementById('stat-checks').textContent   = d.checks24h;
  } catch(e) { console.error(e); }
}

// ── Licenses ─────────────────────────────────────────────────────────────────
async function loadLicenses() {
  const search = document.getElementById('lic-search').value.trim();
  const status = document.getElementById('lic-status').value;
  const plugin = document.getElementById('lic-plugin').value.trim();

  const params = new URLSearchParams({ page: licPage });
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  if (plugin) params.set('plugin', plugin);

  try {
    const data = await api('GET', `/api/licenses?${params}`);
    renderLicenses(data.licenses);
    renderPagination('lic-pagination', data.page, Math.ceil(data.total / data.limit), p => { licPage = p; loadLicenses(); });
  } catch(e) { console.error(e); }
}

function renderLicenses(rows) {
  const tbody = document.getElementById('lic-tbody');
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--muted);padding:24px">No licenses found</td></tr>'; return; }
  tbody.innerHTML = rows.map(r => {
    const expired = new Date(r.expiry_at) < new Date();
    const plugins = (r.plugins || []).join(', ') || '—';
    const expiryStr = r.expiry_at ? new Date(r.expiry_at).toLocaleDateString() : '—';
    const lastSeen = r.last_seen_at ? timeAgo(new Date(r.last_seen_at)) : '—';
    return `<tr class="${expired ? 'expired-row' : ''}">
      <td><code class="mono">${r.key}</code></td>
      <td class="truncate" title="${esc(r.owner_name || '')}">${esc(r.owner_name || '—')}</td>
      <td class="truncate" title="${esc(plugins)}">${esc(plugins)}</td>
      <td>${r.level}</td>
      <td><span class="badge badge-${r.status}">${r.status}</span></td>
      <td>${expiryStr}${expired ? ' <span class="badge badge-warn">Expired</span>' : ''}</td>
      <td>${r.check_count}</td>
      <td>${lastSeen}</td>
      <td>
        <div class="action-group">
          <button class="btn btn-ghost btn-sm" onclick="editLicense(${r.id})">Edit</button>
          <button class="btn btn-ghost btn-sm" onclick="resetHwids(${r.id}, '${r.key}')">Reset HWID</button>
          <button class="btn btn-ghost btn-sm" onclick="toggleStatus(${r.id}, '${r.status}')">
            ${r.status === 'active' ? 'Suspend' : 'Activate'}
          </button>
          <button class="btn btn-danger btn-sm" onclick="deleteLicense(${r.id}, '${r.key}')">Del</button>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function debounceSearch() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { licPage = 1; loadLicenses(); }, 350);
}

// ── License Modal ─────────────────────────────────────────────────────────────
function openCreateModal() {
  editingLicId = null;
  document.getElementById('modal-title').textContent = 'New License';
  document.getElementById('modal-save-btn').textContent = 'Create';
  document.getElementById('modal-error').classList.add('hidden');
  document.getElementById('m-owner').value = '';
  document.getElementById('m-contact').value = '';
  document.getElementById('m-plugins').value = '';
  document.getElementById('m-maxservers').value = 1;
  document.getElementById('m-level').value = 1;
  // Default expiry = 1 year from now
  const d = new Date(); d.setFullYear(d.getFullYear() + 1);
  document.getElementById('m-expiry').value = d.toISOString().slice(0,10);
  document.getElementById('modal-backdrop').classList.remove('hidden');
}

async function editLicense(id) {
  try {
    const r = await api('GET', `/api/licenses/${id}`);
    editingLicId = id;
    document.getElementById('modal-title').textContent = `Edit — ${r.key}`;
    document.getElementById('modal-save-btn').textContent = 'Save';
    document.getElementById('modal-error').classList.add('hidden');
    document.getElementById('m-owner').value = r.owner_name || '';
    document.getElementById('m-contact').value = r.owner_contact || '';
    document.getElementById('m-plugins').value = (r.plugins || []).join(',');
    document.getElementById('m-maxservers').value = r.max_servers;
    document.getElementById('m-level').value = r.level;
    document.getElementById('m-expiry').value = r.expiry_at ? r.expiry_at.slice(0,10) : '';
    document.getElementById('modal-backdrop').classList.remove('hidden');
  } catch(e) { alert('Error: ' + e.message); }
}

function closeModal() {
  document.getElementById('modal-backdrop').classList.add('hidden');
}

async function saveModal() {
  const errEl = document.getElementById('modal-error');
  errEl.classList.add('hidden');

  const plugins = document.getElementById('m-plugins').value
    .split(',').map(s => s.trim()).filter(Boolean);

  const payload = {
    owner_name:    document.getElementById('m-owner').value.trim() || null,
    owner_contact: document.getElementById('m-contact').value.trim() || null,
    plugins,
    max_servers:   parseInt(document.getElementById('m-maxservers').value),
    level:         parseInt(document.getElementById('m-level').value),
    expiry_at:     document.getElementById('m-expiry').value,
  };

  try {
    if (editingLicId) {
      await api('PATCH', `/api/licenses/${editingLicId}`, payload);
    } else {
      await api('POST', '/api/licenses', payload);
    }
    closeModal();
    loadLicenses();
  } catch(e) {
    errEl.textContent = e.message;
    errEl.classList.remove('hidden');
  }
}

async function resetHwids(id, key) {
  if (!confirm(`Reset HWID bindings for ${key}?`)) return;
  try {
    await api('POST', `/api/licenses/${id}/reset-hwids`);
    loadLicenses();
  } catch(e) { alert('Error: ' + e.message); }
}

async function toggleStatus(id, current) {
  const newStatus = current === 'active' ? 'suspended' : 'active';
  if (!confirm(`${newStatus === 'suspended' ? 'Suspend' : 'Activate'} this license?`)) return;
  try {
    await api('PATCH', `/api/licenses/${id}`, { status: newStatus });
    loadLicenses();
  } catch(e) { alert('Error: ' + e.message); }
}

async function deleteLicense(id, key) {
  if (!confirm(`DELETE license ${key}? This cannot be undone.`)) return;
  try {
    await api('DELETE', `/api/licenses/${id}`);
    loadLicenses();
  } catch(e) { alert('Error: ' + e.message); }
}

// ── Logs ─────────────────────────────────────────────────────────────────────
async function loadLogs() {
  const result  = document.getElementById('log-result').value;
  const key     = document.getElementById('log-key').value.trim();
  const plugin  = document.getElementById('log-plugin').value.trim();
  const dateFrom= document.getElementById('log-from').value;
  const dateTo  = document.getElementById('log-to').value;

  const params = new URLSearchParams({ page: logPage });
  if (result)   params.set('result', result);
  if (key)      params.set('key', key);
  if (plugin)   params.set('plugin', plugin);
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo)   params.set('date_to', dateTo + 'T23:59:59');

  try {
    const data = await api('GET', `/api/logs?${params}`);
    renderLogs(data.logs);
    renderPagination('log-pagination', data.page, Math.ceil(data.total / data.limit), p => { logPage = p; loadLogs(); });
  } catch(e) { console.error(e); }
}

function renderLogs(rows) {
  const tbody = document.getElementById('log-tbody');
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px">No logs</td></tr>'; return; }
  tbody.innerHTML = rows.map(r => `<tr>
    <td style="white-space:nowrap;font-size:12px">${new Date(r.created_at).toLocaleString()}</td>
    <td><code class="mono">${esc(r.key || '—')}</code></td>
    <td>${esc(r.plugin || '—')}</td>
    <td style="font-size:12px">${esc(r.ip || '—')}</td>
    <td class="mono truncate" style="font-size:11px" title="${esc(r.hwid || '')}">${esc((r.hwid || '—').slice(0,12))}…</td>
    <td><span class="badge badge-${r.result}">${r.result}</span></td>
    <td style="color:var(--muted);font-size:12px">${esc(r.message || '')}</td>
  </tr>`).join('');
}

function debounceLogSearch() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { logPage = 1; loadLogs(); }, 350);
}

// ── Settings ─────────────────────────────────────────────────────────────────
async function loadSettings() {
  try {
    const d = await api('GET', '/api/settings/hmac-secret');
    document.getElementById('hmac-display').textContent = d.masked;
  } catch(e) { console.error(e); }
}

async function changePassword() {
  const alert = document.getElementById('pw-alert');
  alert.className = 'alert hidden';
  const cur = document.getElementById('pw-current').value;
  const nw  = document.getElementById('pw-new').value;
  const cf  = document.getElementById('pw-confirm').value;
  if (nw !== cf) { showAlert(alert, 'error', 'Passwords do not match'); return; }
  try {
    await api('POST', '/api/settings/change-password', { current_password: cur, new_password: nw });
    showAlert(alert, 'success', 'Password updated!');
    document.getElementById('pw-current').value = '';
    document.getElementById('pw-new').value = '';
    document.getElementById('pw-confirm').value = '';
  } catch(e) { showAlert(alert, 'error', e.message); }
}

function showAlert(el, type, msg) {
  el.className = `alert alert-${type}`;
  el.textContent = msg;
}

// ── Pagination ────────────────────────────────────────────────────────────────
function renderPagination(containerId, current, total, onPage) {
  const el = document.getElementById(containerId);
  if (total <= 1) { el.innerHTML = ''; return; }
  let html = '';
  if (current > 1) html += `<button class="btn btn-ghost btn-sm" onclick="(${onPage.toString()})(${current-1})">‹ Prev</button>`;
  // Show up to 7 page buttons
  const start = Math.max(1, current - 3);
  const end   = Math.min(total, start + 6);
  for (let p = start; p <= end; p++) {
    html += `<button class="btn btn-sm ${p === current ? 'btn-primary' : 'btn-ghost'}" onclick="(${onPage.toString()})(${p})">${p}</button>`;
  }
  if (current < total) html += `<button class="btn btn-ghost btn-sm" onclick="(${onPage.toString()})(${current+1})">Next ›</button>`;
  el.innerHTML = html;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function esc(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function timeAgo(date) {
  const sec = Math.floor((Date.now() - date) / 1000);
  if (sec < 60)   return `${sec}s ago`;
  if (sec < 3600) return `${Math.floor(sec/60)}m ago`;
  if (sec < 86400)return `${Math.floor(sec/3600)}h ago`;
  return `${Math.floor(sec/86400)}d ago`;
}

// ── Start ─────────────────────────────────────────────────────────────────────
init();
